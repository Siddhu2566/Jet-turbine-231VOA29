using UnityEngine;

public class QuitMethod : MonoBehaviour
{
    public void quit(){
        Application.Quit();
    }

}
